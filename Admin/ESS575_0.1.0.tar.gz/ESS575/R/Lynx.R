#' @title Lynx population data
#'
#' @description Annual counts of family groups and number of indviduals harvested from Eurasian Lynx management unit in Sweden
#' @name Lynx
#' @docType data
#' @format{ A data frame with 13 observations on the following 3 variables:
#' \describe{
#' \item{\code{yr}}{year of census}
#' \item{\code{census}}{number of family groups in snow tracking survey}
#' \item{\code{harvest}}{number of male, female, and juvenile lynx harvested}
#'}}
NULL
